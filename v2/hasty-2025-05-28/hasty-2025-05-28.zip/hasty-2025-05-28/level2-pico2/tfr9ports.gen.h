#define ACIA_PORT            0xff06
#define BLOCK_PORT           0xff08
#define BOOTHACK_PORT        0xff05
#define CONSOLE_PORT         0xff04
#define EMUDSK_PORT          0xff80
#define N9_LEVEL             0x0002
#define USE_ACIA             0x0001
