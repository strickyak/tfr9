centipede egg
